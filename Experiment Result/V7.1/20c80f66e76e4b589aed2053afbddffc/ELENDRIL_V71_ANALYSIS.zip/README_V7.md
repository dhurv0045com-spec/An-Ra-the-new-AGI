# Elendril V7 analysis snapshot

This bounded text-only bundle excludes model and optimizer payloads. Checkpoint manifests and hashes are reports, not checkpoint bytes. Archive integrity and independent scientific rescore are separate results.
