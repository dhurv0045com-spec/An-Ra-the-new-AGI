# Elendril V7.1 evidence

Archive verification describes bytes, not scientific success. See campaign receipts and independent replay status; causal claims remain unresolved. The analysis bundle contains bounded text reports; the full bundle retains checkpoints.
