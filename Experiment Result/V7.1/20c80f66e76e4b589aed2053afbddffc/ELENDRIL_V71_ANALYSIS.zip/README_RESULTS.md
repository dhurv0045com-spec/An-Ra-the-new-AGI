# Elendril V6 results

- Campaign status: `EXECUTED`
- Independent rescore status: `PASS`
- Source commit: `6104ffd7134cb4cf4b3f340bd060d24a1e2dd200`
- Protocol SHA-256: `fd8ecd82d7405d9504d19db201cad372dcf7a2fb5d99dc38b0ee602e7476d170`

This bundle preserves all available successful, failed, partial, and skipped outputs. Campaign status and rescore status are reported separately; this archive does not promote a model. See `BUNDLE_MANIFEST.json` for the complete member inventory, per-file hashes, and export custody.

The output directory is the primary evidence. The ZIP is a verified snapshot at export time; files written after that snapshot require a later export.
