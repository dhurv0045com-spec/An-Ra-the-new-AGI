# V7.1 evidence summary

CAUSE UNRESOLVED

Status: AVAILABLE
Cohort rows: 324. Matched free/grammar cohorts: 144.
Missing inputs: 0. Report errors: 0.

Descriptive cohort results and matched controls only; no model promotion.
NOT_QUALIFIED: phase evidence not evaluated in this summary
NOT_QUALIFIED: matched fresh baseline required

See report.csv for per-cohort measurements and summary.json for paired comparisons and missing inputs.
