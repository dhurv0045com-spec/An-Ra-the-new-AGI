FORMATION-MUX-001 Science S5. Campaign may span multiple Kaggle sessions.
Raw sealed rows are never persisted. Exact-resume checkpoints stay in Kaggle Output.
LATEST_PROGRESS.json and progress/*.json are diagnostic snapshots.
